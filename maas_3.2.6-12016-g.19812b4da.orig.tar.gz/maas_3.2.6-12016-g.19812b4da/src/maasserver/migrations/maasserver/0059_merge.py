from django.db import migrations


class Migration(migrations.Migration):

    dependencies = [
        ("maasserver", "0058_bigger_integer_for_dns_publication_serial"),
        ("maasserver", "0057_merge"),
    ]

    operations = []
