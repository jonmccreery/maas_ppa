# Copyright 2016 Canonical Ltd.  This software is licensed under the
# GNU Affero General Public License version 3 (see the file LICENSE).

"""Execute MAAS's Django subsystem."""

from maasserver import execute_from_command_line

raise SystemExit(execute_from_command_line())
